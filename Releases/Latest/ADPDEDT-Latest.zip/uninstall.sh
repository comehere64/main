#!/system/bin/sh
rm -rf /data/adb/ADPDEDT